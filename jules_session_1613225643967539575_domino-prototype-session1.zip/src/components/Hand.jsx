// src/components/Hand.jsx
import React from 'react';
import Tile from './Tile';

const Hand = ({ player, isTurn, onPlayTile }) => {
    return (
        <div style={{ 
            padding: '10px', 
            backgroundColor: isTurn ? '#e6ffe6' : '#f0f0f0',
            border: isTurn ? '2px solid green' : '1px solid #ccc',
            marginBottom: '10px'
        }}>
            <h3>{player.name} (Score: {player.score}) {isTurn ? " - YOUR TURN" : ""}</h3>
            <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                {player.hand.map((tile, index) => (
                    <Tile 
                        key={index} 
                        value={tile} 
                        selectable={isTurn}
                        onClick={() => isTurn && onPlayTile(index)}
                    />
                ))}
            </div>
            {player.hand.length === 0 && <p>Winner!</p>}
        </div>
    );
};

export default Hand;
