// src/components/Tile.jsx
import React from 'react';

const Tile = ({ value, onClick, selectable, style }) => {
    // value is [a, b]
    if (!value) return null;
    
    const [top, bottom] = value;

    return (
        <div 
            onClick={onClick}
            style={{
                width: '40px',
                height: '80px',
                border: '2px solid black',
                borderRadius: '4px',
                backgroundColor: 'white',
                display: 'flex',
                flexDirection: 'column',
                cursor: selectable ? 'pointer' : 'default',
                margin: '2px',
                boxShadow: selectable ? '0 0 5px gold' : 'none',
                ...style
            }}
        >
            <div style={{ flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', borderBottom: '1px solid #ccc', fontSize: '20px', fontWeight: 'bold' }}>
                {top}
            </div>
            <div style={{ flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', fontSize: '20px', fontWeight: 'bold' }}>
                {bottom}
            </div>
        </div>
    );
};

export default Tile;
