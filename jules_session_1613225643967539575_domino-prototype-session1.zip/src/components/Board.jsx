// src/components/Board.jsx
import React from 'react';
import Tile from './Tile';

const Board = ({ board, openEnds }) => {
    return (
        <div style={{ 
            minHeight: '200px', 
            backgroundColor: '#35654d', // Felt green
            padding: '20px',
            overflowX: 'auto',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center' // Simplistic center
        }}>
            {board.length === 0 && <div style={{color: 'white'}}>Waiting for first move...</div>}
            
            <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
                {board.map((item, index) => {
                    // For visualization, we need to orient tiles correctly.
                    // This is tricky in a simple flex row.
                    // Logic already determined connectivity.
                    // Let's just display them vertically [a|b] side by side.
                    // But we might need to flip them visually to match numbers.
                    // If we stored connections, we'd know.
                    // Quick hack: Just render as is for now, users match numbers mentally.
                    // Better: Try to orient.
                    
                    // item.tile is [a, b]
                    return (
                        <div key={index} style={{ margin: '0 5px' }}>
                             <Tile value={item.tile} />
                             {/* Debug info */}
                             {/* <small style={{color:'white'}}>{item.side}</small> */}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default Board;
