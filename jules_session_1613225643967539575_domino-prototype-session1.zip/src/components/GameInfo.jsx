// src/components/GameInfo.jsx
import React from 'react';

const GameInfo = ({ currentTurn, status, log }) => {
    return (
        <div style={{ padding: '10px', borderLeft: '1px solid #ccc', width: '300px' }}>
            <h2>Game Status</h2>
            <p>Current Turn: Player {currentTurn + 1}</p>
            {status && <p style={{color: 'red', fontWeight: 'bold'}}>{status}</p>}
            
            <h3>Log</h3>
            <div style={{ height: '300px', overflowY: 'auto', backgroundColor: '#eee', padding: '5px' }}>
                {log.slice().reverse().map((entry, i) => (
                    <div key={i} style={{ borderBottom: '1px solid #ddd', fontSize: '0.9em' }}>
                        {entry}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default GameInfo;
