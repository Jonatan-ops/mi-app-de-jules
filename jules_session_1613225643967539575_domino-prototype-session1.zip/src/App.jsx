// src/App.jsx
import React, { useState, useEffect, useRef } from 'react';
import { DominoEngine } from './game/DominoEngine';
import Hand from './components/Hand';
import Board from './components/Board';
import GameInfo from './components/GameInfo';

function App() {
  const engineRef = useRef(new DominoEngine());
  const [gameState, setGameState] = useState(0); // Tick to trigger re-render
  
  const engine = engineRef.current;
  
  const refresh = () => setGameState(prev => prev + 1);

  const handlePlayTile = (playerIndex, tileIndex) => {
      // Try auto-side first
      let result = engine.playTile(playerIndex, tileIndex);
      if (!result.success && result.message.includes("Ambiguous")) {
          // Ask user for side
          const side = window.prompt("Play on 'left' or 'right'?");
          if (side === 'left' || side === 'right') {
              result = engine.playTile(playerIndex, tileIndex, side);
          }
      }
      
      if (!result.success) {
          alert(result.message);
      }
      refresh();
  };

  const handlePass = () => {
      const result = engine.pass();
      if (result && !result.success) {
          alert(result.message);
      }
      refresh();
  };
  
  const handleBotMove = () => {
      if (engine.isGameOver) return;
      
      // Attempt to find a move for current player
      const move = engine.getBotMove(engine.currentTurn);
      
      if (move) {
          engine.playTile(engine.currentTurn, move.index, move.side);
      } else {
          engine.pass();
      }
      refresh();
  };
  
  const handleRestart = () => {
      engine.reset();
      refresh();
  };

  return (
    <div style={{ display: 'flex', height: '100vh', flexDirection: 'column' }}>
      <div style={{ padding: '10px', background: '#333', color: 'white', display: 'flex', justifyContent: 'space-between' }}>
        <h1>Domino Royale Prototype</h1>
        <div>
            <button onClick={handleBotMove} disabled={engine.isGameOver} style={{ marginRight: '10px', padding: '5px 15px', cursor: 'pointer' }}>
                🤖 Bot Move (Current Player)
            </button>
            <button onClick={handleRestart} style={{ padding: '5px 15px', cursor: 'pointer' }}>
                Restart Game
            </button>
        </div>
      </div>
      
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflowY: 'auto' }}>
            <Board board={engine.board} openEnds={engine.openEnds} />
            
            <div style={{ padding: '10px' }}>
                {engine.isGameOver && (
                    <div style={{ padding: '20px', backgroundColor: 'gold', textAlign: 'center', margin: '10px' }}>
                        <h2>GAME OVER</h2>
                        <p>{engine.winner ? `${engine.winner.name} Wins!` : "It's a tie!"}</p>
                    </div>
                )}
                
                {/* Render Hands */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                    {engine.players.map((player, index) => (
                        <Hand 
                            key={player.id} 
                            player={player} 
                            isTurn={engine.currentTurn === index && !engine.isGameOver}
                            onPlayTile={(tileIndex) => handlePlayTile(index, tileIndex)}
                        />
                    ))}
                </div>
                
                {/* Controls for current player if they need to pass */}
                {!engine.isGameOver && (
                    <div style={{ padding: '10px', textAlign: 'center' }}>
                         <button 
                            onClick={handlePass}
                            style={{ padding: '10px 20px', fontSize: '16px', cursor: 'pointer' }}
                         >
                            Pass Turn (If no tiles match)
                         </button>
                    </div>
                )}
            </div>
          </div>
          
          <GameInfo 
            currentTurn={engine.currentTurn} 
            status={engine.isGameOver ? "Game Over" : "Playing"} 
            log={engine.gameLog} 
          />
      </div>
    </div>
  );
}

export default App;
