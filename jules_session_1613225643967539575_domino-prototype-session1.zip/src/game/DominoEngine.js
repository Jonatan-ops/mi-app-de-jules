// src/game/DominoEngine.js

export class DominoEngine {
    constructor() {
        this.reset();
    }

    reset() {
        this.deck = this.generateDeck();
        this.players = [
            { id: 0, name: 'Player 1', hand: [], score: 0 },
            { id: 1, name: 'Player 2', hand: [], score: 0 },
            { id: 2, name: 'Player 3', hand: [], score: 0 },
            { id: 3, name: 'Player 4', hand: [], score: 0 }
        ];
        this.board = []; // Array of played tiles: { left: number, right: number }
        // "board" visualization is complex (snaking). 
        // For logic, we mainly need to know the open ends.
        // But for UI we need the history.
        // Let's store logic representation separately if needed, but simple array is fine.
        // We will store tiles in order they are connected.
        // First tile is simple. Subsequent tiles attach to head or tail.
        
        this.openEnds = { left: null, right: null }; // The available numbers to match
        
        this.currentTurn = 0;
        this.winner = null;
        this.isGameOver = false;
        this.gameLog = [];
        
        this.deal();
    }

    generateDeck() {
        const deck = [];
        for (let i = 0; i <= 6; i++) {
            for (let j = i; j <= 6; j++) {
                deck.push([i, j]);
            }
        }
        return this.shuffle(deck);
    }

    shuffle(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    deal() {
        // 4 players, 7 tiles each. 28 tiles total.
        for (let i = 0; i < 4; i++) {
            this.players[i].hand = this.deck.splice(0, 7);
        }
        
        // Determine who starts
        // Rule: Player with double 6 starts. If no one has double 6, double 5, etc.
        // Simplified: Player 0 starts or double-6 holder starts.
        // Let's implement Double-6 start rule for authenticity.
        
        let startPlayer = -1;
        let startTileIndex = -1;
        
        // Find highest double
        for (let d = 6; d >= 0; d--) {
            if (startPlayer !== -1) break;
            for (let p = 0; p < 4; p++) {
                const idx = this.players[p].hand.findIndex(t => t[0] === d && t[1] === d);
                if (idx !== -1) {
                    startPlayer = p;
                    startTileIndex = idx;
                    break;
                }
            }
        }
        
        // If no doubles (statistically possible?), find highest sum
        if (startPlayer === -1) {
             let maxPips = -1;
             for (let p = 0; p < 4; p++) {
                 this.players[p].hand.forEach((t, idx) => {
                     if (t[0] + t[1] > maxPips) {
                         maxPips = t[0] + t[1];
                         startPlayer = p;
                         startTileIndex = idx;
                     }
                 });
             }
        }

        this.currentTurn = startPlayer;
        this.gameLog.push(`Game started. ${this.players[startPlayer].name} has the lead.`);
    }

    // Attempt to play a tile
    // side: 'left' or 'right'. If null, auto-detect (if only one option).
    playTile(playerIndex, tileIndex, side = null) {
        if (this.isGameOver) return { success: false, message: "Game is over" };
        if (playerIndex !== this.currentTurn) return { success: false, message: "Not your turn" };

        const player = this.players[playerIndex];
        const tile = player.hand[tileIndex]; // [a, b]

        // First move logic
        if (this.board.length === 0) {
            // First tile played
            player.hand.splice(tileIndex, 1);
            this.board.push({ tile: tile, start: true }); // 'start' just marks the first one
            this.openEnds = { left: tile[0], right: tile[1] };
            this.logMove(player.name, tile, "started");
            this.nextTurn();
            return { success: true };
        }

        // Validate move
        // Ends are openEnds.left and openEnds.right
        // Tile is [a, b]. Can match a or b to left or right.
        
        let validLeft = false;
        let validRight = false;
        let flip = false; // Do we need to display it flipped? (Logic-wise we just need to know what's exposed)
        
        // Check match on Left
        // If openEnds.left is 6, we need a 6.
        // If tile is [6, 2], we match 6. Exposed becomes 2.
        // If tile is [2, 6], we match 6. Exposed becomes 2.
        
        // Determine matches
        const matchesLeft = (tile[0] === this.openEnds.left || tile[1] === this.openEnds.left);
        const matchesRight = (tile[0] === this.openEnds.right || tile[1] === this.openEnds.right);

        if (!matchesLeft && !matchesRight) {
             return { success: false, message: "Invalid move: Tile does not match open ends." };
        }

        // Ambiguity check (Doubles often match both sides if both ends are same number, but rule is simple: user picks)
        if (matchesLeft && matchesRight && this.openEnds.left !== this.openEnds.right) {
            // Ambiguous only if ends are different but tile matches both?
            // e.g. Ends: 3...5. Tile [3,5]. Can play on either side.
            if (!side) return { success: false, message: "Ambiguous move. Please select Left or Right." };
        }

        // Auto-select side if not provided
        let chosenSide = side;
        if (!chosenSide) {
            if (matchesLeft && !matchesRight) chosenSide = 'left';
            else if (!matchesLeft && matchesRight) chosenSide = 'right';
            else {
                 // Matches both (e.g. Ends 3...3, Tile [3,6] OR Ends 3...5, Tile [3,5])
                 // If ends are same (3...3) and tile matches (3), it doesn't matter which side usually, 
                 // but for visualization it might. Let's default to Left for simplicity unless specified.
                 // Actually for [3,5] on 3...5, side MATTERS.
                 if (this.openEnds.left !== this.openEnds.right) {
                     return { success: false, message: "Ambiguous move. Please select Left or Right." };
                 }
                 chosenSide = 'left'; // Default for doubles or same-end scenarios
            }
        }

        // Execute move
        let newOpenVal;
        
        if (chosenSide === 'left') {
            if (tile[1] === this.openEnds.left) {
                // Tile [a, 6] matching 6. New open is a.
                newOpenVal = tile[0];
                // Visuals: [a, 6] - [6, x]...
            } else if (tile[0] === this.openEnds.left) {
                // Tile [6, a] matching 6. New open is a.
                newOpenVal = tile[1];
            } else {
                return { success: false, message: "Tile does not match Left end." };
            }
            this.openEnds.left = newOpenVal;
            // Add to board beginning
            this.board.unshift({ tile: tile, side: 'left' }); 
        } else {
            // Right
            if (tile[0] === this.openEnds.right) {
                // ...[x, 6] - [6, a]
                newOpenVal = tile[1];
            } else if (tile[1] === this.openEnds.right) {
                // ...[x, 6] - [a, 6]
                newOpenVal = tile[0];
            } else {
                return { success: false, message: "Tile does not match Right end." };
            }
            this.openEnds.right = newOpenVal;
            this.board.push({ tile: tile, side: 'right' });
        }

        player.hand.splice(tileIndex, 1);
        this.logMove(player.name, tile, `on the ${chosenSide}`);

        if (this.checkWin(player)) return { success: true, gameOver: true };
        
        this.nextTurn();
        return { success: true };
    }

    pass() {
        if (this.isGameOver) return;
        const player = this.players[this.currentTurn];
        
        // Validate that player REALLY cannot play
        const canPlay = player.hand.some(tile => 
            tile[0] === this.openEnds.left || tile[1] === this.openEnds.left ||
            tile[0] === this.openEnds.right || tile[1] === this.openEnds.right
        );
        
        if (canPlay) {
            return { success: false, message: "You have playable tiles. Cannot pass." };
        }
        
        this.logMove(player.name, null, "passed");
        
        // Check for Blocked Game (All 4 players passed consecutively)
        // We need to track consecutive passes.
        // A simple way is to check if ANY move is possible for ANY player.
        // Or just count passes.
        // Let's count passes in nextTurn logic.
        
        this.nextTurn(true); 
        return { success: true };
    }
    
    nextTurn(wasPass = false) {
        if (wasPass) {
            this.consecutivePasses = (this.consecutivePasses || 0) + 1;
        } else {
            this.consecutivePasses = 0;
        }

        if (this.consecutivePasses >= 4) {
            this.handleBlockedGame();
            return;
        }

        this.currentTurn = (this.currentTurn + 1) % 4;
        
        // Auto-check if next player MUST pass?
        // For UI, better to let user/bot realize they must pass.
    }

    checkWin(player) {
        if (player.hand.length === 0) {
            this.endGame(player.id, 'Domino!');
            return true;
        }
        return false;
    }

    handleBlockedGame() {
        // Count pips for each player
        let minPips = 1000;
        let winnerIndex = -1;
        
        // Calculate scores
        const pipCounts = this.players.map(p => {
            return p.hand.reduce((sum, tile) => sum + tile[0] + tile[1], 0);
        });
        
        // Find winner (lowest pips)
        // Tie-breaker rules vary. Usually in teams, team sum. Individual?
        // Individual tie: Usually player who played last? Or draw?
        // Let's assume standard: Lowest wins. Tie = Draw (no points) or split?
        // Let's give it to the first one found or handle tie later.
        
        minPips = Math.min(...pipCounts);
        // Check for ties
        const winners = [];
        pipCounts.forEach((count, idx) => {
            if (count === minPips) winners.push(idx);
        });
        
        if (winners.length === 1) {
            this.endGame(winners[0], 'Blocked Game');
        } else {
            // It's a tie. 
            this.isGameOver = true;
            this.winner = null; // No single winner
            this.gameLog.push(`Game Blocked. It's a tie between players ${winners.join(' and ')}.`);
        }
    }

    endGame(winnerIndex, method) {
        this.isGameOver = true;
        this.winner = this.players[winnerIndex];
        
        // Calculate Prize: Sum of all opponents' points
        let totalOpponentPoints = 0;
        this.players.forEach(p => {
            if (p.id !== winnerIndex) {
                 const pips = p.hand.reduce((sum, tile) => sum + tile[0] + tile[1], 0);
                 totalOpponentPoints += pips;
            }
        });
        
        this.winner.score += totalOpponentPoints; // Add to winner's score (money/points)
        
        this.gameLog.push(`Game Over! ${this.winner.name} won by ${method}.`);
        this.gameLog.push(`${this.winner.name} collects ${totalOpponentPoints} points from opponents.`);
    }

    logMove(playerName, tile, action) {
        const tileStr = tile ? `[${tile[0]}|${tile[1]}]` : "";
        this.gameLog.push(`${playerName} ${action} ${tileStr}`);
    }
    
    // Bot Helper
    getBotMove(playerIndex) {
        const player = this.players[playerIndex];
        const validMoves = [];

        // Special case: First move of the game
        if (this.board.length === 0) {
            // Can play any tile? 
            // In our `deal` logic, we determined startPlayer based on Double 6 (or highest).
            // Usually they MUST play that specific tile if we want to be strict, 
            // but `deal` just sets the turn. `playTile` allows any tile for first move currently.
            // Let's pick the highest double or highest tile to start.
            
            // For simplicity, just pick the first tile in hand or a double if available.
            // Let's try to match the "Start Logic" from Deal (Double 6).
            // If the player has [6,6], play it.
            const d6Index = player.hand.findIndex(t => t[0] === 6 && t[1] === 6);
            if (d6Index !== -1) {
                 validMoves.push({ index: d6Index, side: null, tile: player.hand[d6Index] });
            } else {
                 // Any tile is valid for engine on first move
                 player.hand.forEach((tile, index) => {
                     validMoves.push({ index, side: null, tile });
                 });
            }
        } else {
            // Normal play
            player.hand.forEach((tile, index) => {
                 // Check Left
                 if (tile[0] === this.openEnds.left || tile[1] === this.openEnds.left) {
                     validMoves.push({ index, side: 'left', tile });
                 }
                 // Check Right
                 if (tile[0] === this.openEnds.right || tile[1] === this.openEnds.right) {
                     // Check if we already added this as 'left' (ambiguous case)
                     // If openEnds.left == openEnds.right, we might add it twice.
                     // It's fine to have two options in validMoves, the bot picks one.
                     validMoves.push({ index, side: 'right', tile });
                 }
            });
        }
        
        if (validMoves.length === 0) return null;
        
        // Strategy: Pick first one (Random/Naive)
        // Or pick highest double? 
        return validMoves[0];
    }
}
